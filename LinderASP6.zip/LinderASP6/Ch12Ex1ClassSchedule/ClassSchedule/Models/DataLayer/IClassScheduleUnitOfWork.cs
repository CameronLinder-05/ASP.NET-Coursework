﻿using ClassSchedule.Models;

namespace ClassSchedule.Models.DataLayer
{
    public interface IClassScheduleUnitOfWork
    {
        Repository<Class> Classes { get; }
        Repository<Teacher> Teachers { get; }
        Repository<Day> Days { get; }

        void Save();
    }
}