﻿using ClassSchedule.Models;

namespace ClassSchedule.Models.DataLayer
{
    public class ClassScheduleUnitOfWork : IClassScheduleUnitOfWork
    {
        private readonly ClassScheduleContext context;

        private Repository<Class>? classes;
        private Repository<Teacher>? teachers;
        private Repository<Day>? days;

        public ClassScheduleUnitOfWork(ClassScheduleContext ctx)
        {
            context = ctx;
        }

        public Repository<Class> Classes
        {
            get { return classes ??= new Repository<Class>(context); }
        }

        public Repository<Teacher> Teachers
        {
            get { return teachers ??= new Repository<Teacher>(context); }
        }

        public Repository<Day> Days
        {
            get { return days ??= new Repository<Day>(context); }
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}