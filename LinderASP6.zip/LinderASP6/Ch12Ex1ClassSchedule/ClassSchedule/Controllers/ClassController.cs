﻿using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;
using ClassSchedule.Models.DataLayer;

namespace ClassSchedule.Controllers
{
    public class ClassController : Controller
    {
        private IClassScheduleUnitOfWork data { get; set; }

        public ClassController(IClassScheduleUnitOfWork uow)
        {
            data = uow;
        }

        public RedirectToActionResult Index() => RedirectToAction("Index", "Home");

        [HttpGet]
        public ViewResult Add()
        {
            this.LoadViewBag("Add");
            return View("AddEdit", new Class());
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            this.LoadViewBag("Edit");
            var c = this.GetClass(id);
            return View("AddEdit", c);
        }

        [HttpPost]
        public IActionResult Add(Class c)
        {
            bool isAdd = c.ClassId == 0;

            if (ModelState.IsValid)
            {
                if (isAdd)
                    data.Classes.Insert(c);
                else
                    data.Classes.Update(c);

                data.Save();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                string operation = (isAdd) ? "Add" : "Edit";
                this.LoadViewBag(operation);
                return View("AddEdit", c);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var c = this.GetClass(id);
            return View(c);
        }

        [HttpPost]
        public RedirectToActionResult Delete(Class c)
        {
            data.Classes.Delete(c);
            data.Save();
            return RedirectToAction("Index", "Home");
        }

        // private helper methods
        private Class GetClass(int id)
        {
            var classOptions = new QueryOptions<Class>
            {
                Includes = "Teacher, Day",
                Where = c => c.ClassId == id
            };

            return data.Classes.Get(classOptions) ?? new Class();
        }

        private void LoadViewBag(string operation)
        {
            ViewBag.Days = data.Days.List(new QueryOptions<Day>
            {
                OrderBy = d => d.DayId
            });

            ViewBag.Teachers = data.Teachers.List(new QueryOptions<Teacher>
            {
                OrderBy = t => t.LastName
            });

            ViewBag.Operation = operation;
        }
    }
}