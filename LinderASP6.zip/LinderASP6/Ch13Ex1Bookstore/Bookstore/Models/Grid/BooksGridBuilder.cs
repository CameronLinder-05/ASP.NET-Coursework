﻿using Microsoft.AspNetCore.Http;

namespace Bookstore.Models
{
    public class BooksGridBuilder
    {
        private const string RouteKey = "book-route";
        private ISession session { get; set; }

        public BooksGridBuilder(ISession sess)
        {
            session = sess;
            CurrentRoute = session.GetObject<BookGridData>(RouteKey) ?? new BookGridData();
        }

        public BookGridData CurrentRoute { get; set; }

        public void SaveRouteSegments() => session.SetObject(RouteKey, CurrentRoute);
    }
}