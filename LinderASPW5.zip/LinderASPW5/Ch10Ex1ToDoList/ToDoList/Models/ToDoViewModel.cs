﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToDoList.Models;

namespace ToDoList.Models
{
    public class ToDoViewModel
    {
        public ToDoViewModel()
        {
            CurrentTask = new ToDo();
            Tasks = new List<ToDo>();
            Categories = new List<Category>();
            Statuses = new List<Status>();
            DueFilters = new Dictionary<string, string>();
        }

        public Filters Filters { get; set; }
        public List<Status> Statuses { get; set; }
        public List<Category> Categories { get; set; }
        public Dictionary<string, string> DueFilters { get; set; }
        public List<ToDo> Tasks { get; set; }
        public ToDo CurrentTask { get; set; } 
    }
}