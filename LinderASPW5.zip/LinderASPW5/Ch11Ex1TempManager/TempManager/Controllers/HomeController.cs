﻿using Microsoft.AspNetCore.Mvc;
using TempManager.Models;

namespace TempManager.Controllers
{
    public class HomeController : Controller
    {
        private TempManagerContext data { get; set; }

        public HomeController(TempManagerContext ctx) => data = ctx;

        public ViewResult Index()
        {
            var temps = data.Temps
                            .OrderBy(t => t.Date)
                            .ToList();

            return View(temps);
        }

        [HttpGet]
        public ViewResult Add() => View(new Temp());

        [HttpPost]
        public IActionResult Add(Temp temp)
        {
            // Check for duplicate date
            if (temp.Date.HasValue)
            {
                bool dateExists = data.Temps
                                      .Any(t => t.Date == temp.Date);

                if (dateExists)
                {
                    // Property-level validation error
                    ModelState.AddModelError(nameof(Temp.Date),
                                             "Date already exists.");
                }
            }

            if (ModelState.IsValid)
            {
                data.Temps.Add(temp);
                data.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                // Model-level validation error
                ModelState.AddModelError(string.Empty,
                                         "Please correct all errors");

                return View(temp);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var temp = data.Temps.Find(id);

            if (temp == null)
            {
                return RedirectToAction("Index");
            }

            return View(temp);
        }

        [HttpPost]
        public RedirectToActionResult Delete(Temp temp)
        {
            data.Temps.Remove(temp);
            data.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}